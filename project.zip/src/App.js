import "./App.css";
// import { Route, Router } from "react-router";
import Calculator from "./components/Calculator";

function App() {
  return (
    <div>
      <Calculator />
    </div>
  );
}

export default App;
